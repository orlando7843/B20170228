﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListBoxTemplate
{
    public class TodoModel
    {
        //auto implemented property
        public string Title { get; set; }
        public int Completion { get; set; }
    }
}

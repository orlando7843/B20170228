namespace Gemini.Framework.Menus
{
    public class MenuBarDefinition
    {

    }
}
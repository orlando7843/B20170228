﻿namespace Gemini.Framework.Services
{
	public enum PaneLocation
	{
		Left,
		Right,
		Bottom
	}
}
using System;
using Caliburn.Micro;

namespace Gemini.Framework
{
	public abstract class WindowBase : Screen, IWindow
	{
	    
	}
}
﻿namespace Gemini.Framework
{
    internal interface IExecutableItem
    {
        void RaiseCanExecuteChanged();
    }
}
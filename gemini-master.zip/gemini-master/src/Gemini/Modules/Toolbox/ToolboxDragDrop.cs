﻿namespace Gemini.Modules.Toolbox
{
    public static class ToolboxDragDrop
    {
        public const string DataFormat = "GeminiToolboxItem";
    }
}
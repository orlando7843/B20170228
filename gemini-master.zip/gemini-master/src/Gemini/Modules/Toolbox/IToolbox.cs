﻿using Gemini.Framework;

namespace Gemini.Modules.Toolbox
{
    public interface IToolbox : ITool
    {
         
    }
}
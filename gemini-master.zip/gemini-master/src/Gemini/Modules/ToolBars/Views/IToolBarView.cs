﻿using System.Windows.Controls;

namespace Gemini.Modules.ToolBars.Views
{
    public interface IToolBarsView
    {
        ToolBarTray ToolBarTray { get; }
    }
}
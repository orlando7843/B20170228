﻿using Caliburn.Micro;

namespace Gemini.Modules.ToolBars.Models
{
	public class ToolBarModel : BindableCollection<ToolBarItemBase>, IToolBar
	{
        
	}
}
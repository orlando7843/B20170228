﻿namespace Gemini.Modules.ToolBars.Models
{
	public class ToolBarItemSeparator : ToolBarItemBase
	{
		 
	}
}
﻿namespace Gemini.Modules.MainWindow.Views
{
	public partial class MainWindowView
    {
        public MainWindowView()
		{
			InitializeComponent();
		}
	}
}

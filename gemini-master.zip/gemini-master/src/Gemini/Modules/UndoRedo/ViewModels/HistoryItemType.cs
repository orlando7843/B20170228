﻿namespace Gemini.Modules.UndoRedo.ViewModels
{
    public enum HistoryItemType
    {
        InitialState,
        Undo,
        Current,
        Redo
    }
}
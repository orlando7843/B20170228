﻿namespace Gemini.Modules.MainMenu.Models
{
	public class MenuItemSeparator : MenuItemBase
	{
		 
	}
}
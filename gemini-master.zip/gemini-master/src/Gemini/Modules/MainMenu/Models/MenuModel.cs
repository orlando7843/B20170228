﻿using Caliburn.Micro;

namespace Gemini.Modules.MainMenu.Models
{
	public class MenuModel : BindableCollection<MenuItemBase>, IMenu
	{
		
	}
}
﻿using System.Windows.Controls;

namespace Gemini.Modules.MainMenu.Views
{
    /// <summary>
    ///     Interaction logic for MainMenuSettingsView.xaml
    /// </summary>
    public partial class MainMenuSettingsView : UserControl
    {
        public MainMenuSettingsView()
        {
            InitializeComponent();
        }
    }
}
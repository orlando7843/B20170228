﻿using System.ComponentModel.Composition;
using Gemini.Framework;

namespace Gemini.Modules.GraphEditor
{
    [Export(typeof(IModule))]
    public class Module : ModuleBase
    {
        
    }
}
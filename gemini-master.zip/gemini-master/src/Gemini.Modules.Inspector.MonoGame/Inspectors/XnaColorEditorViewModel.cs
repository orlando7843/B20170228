﻿using Gemini.Modules.Inspector.Inspectors;
using Microsoft.Xna.Framework;

namespace Gemini.Modules.Inspector.MonoGame.Inspectors
{
    public class XnaColorEditorViewModel : EditorBase<Color>, ILabelledInspector
    {
        
    }
}
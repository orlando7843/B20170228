﻿namespace Gemini.Modules.Inspector.Inspectors
{
    public class CheckBoxEditorViewModel : EditorBase<bool>, ILabelledInspector
    {
         
    }
}
﻿using System.Windows.Controls;

namespace Gemini.Modules.Inspector.Inspectors
{
    /// <summary>
    /// Interaction logic for Point3DEditorView.xaml
    /// </summary>
    public partial class Point3DEditorView : UserControl
    {
        public Point3DEditorView()
        {
            InitializeComponent();
        }
    }
}

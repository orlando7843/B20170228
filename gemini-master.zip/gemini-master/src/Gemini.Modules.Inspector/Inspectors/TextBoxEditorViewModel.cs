﻿namespace Gemini.Modules.Inspector.Inspectors
{
    public class TextBoxEditorViewModel<T> : EditorBase<T>, ILabelledInspector
    {
        
    }
}
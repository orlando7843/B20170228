﻿namespace Gemini.Modules.Inspector.Inspectors
{
    public interface ILabelledInspector
    {
         
    }
}
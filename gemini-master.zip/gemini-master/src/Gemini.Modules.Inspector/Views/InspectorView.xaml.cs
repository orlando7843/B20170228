﻿using System.Windows.Controls;

namespace Gemini.Modules.Inspector.Views
{
    /// <summary>
    /// Interaction logic for InspectorView.xaml
    /// </summary>
    public partial class InspectorView : UserControl
    {
        public InspectorView()
        {
            InitializeComponent();
        }
    }
}

﻿namespace Gemini.Demo.MonoGame.Modules.SceneViewer.Views
{
    public interface ISceneView
    {
        void Invalidate();
    }
}
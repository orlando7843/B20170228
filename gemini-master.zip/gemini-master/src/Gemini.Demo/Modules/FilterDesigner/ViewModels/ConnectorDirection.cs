﻿namespace Gemini.Demo.Modules.FilterDesigner.ViewModels
{
    public enum ConnectorDirection
    {
        Input,
        Output
    }
}
﻿using System.Windows.Controls;

namespace Gemini.Modules.Inspector.Xna.Inspectors
{
	/// <summary>
	/// Interaction logic for Vector3EditorView.xaml
	/// </summary>
	public partial class Vector3EditorView : UserControl
	{
		public Vector3EditorView()
		{
			InitializeComponent();
		}
	}
}

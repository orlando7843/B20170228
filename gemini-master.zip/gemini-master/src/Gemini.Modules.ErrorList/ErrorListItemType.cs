﻿namespace Gemini.Modules.ErrorList
{
    public enum ErrorListItemType
    {
        Error,
        Warning,
        Message
    }
}